-- =============================================
-- BuzzBuy Seed Data for Spring Boot initialization
-- Safe to re-run
-- =============================================

-- Demo user (password = "password" for this bcrypt)
INSERT INTO users (id, name, email, mobile, password_hash, role) VALUES
(1, 'Demo User', 'demo@example.com', '9876543210',
 '$2a$10$Z4Hobbghqtdpcjm4mVvfNO0Y8i8nDA6Oi2Ll8iAna6XRpERuj.Kzq',
 'USER')
ON DUPLICATE KEY UPDATE
 name=VALUES(name),
 email=VALUES(email),
 mobile=VALUES(mobile),
 password_hash=VALUES(password_hash),
 role=VALUES(role);

-- Categories (stable IDs so products can reference them)
INSERT INTO categories (id, name, description) VALUES
  (1, 'Electronics', 'Phones, laptops, and gadgets'),
  (2, 'Clothing', 'Apparel and accessories'),
  (3, 'Furniture', 'Sofas, tables, and chairs'),
  (4, 'Food', 'Snacks and groceries')
ON DUPLICATE KEY UPDATE
 name = VALUES(name),
 description = VALUES(description);

-- Products
INSERT INTO products (id, name, description, price, image_url, stock, category_id) VALUES
  (1, 'Laptop', 'Portable and powerful.', 25000.00, 'images/laptop.jpg', 25, 1),
  (2, 'Shirt', 'Soft cotton Collar neck.', 699.00, 'images/pant.png', 100, 2),
  (3, 'Jacket', 'Comfortable Fashion Jacket.', 999.00, 'images/jacket1.jpg', 50, 2),
  (4, 'Jacket', 'New Trendy Jacket.', 1099.00, 'images/jacket2.jpg', 40, 2),
  (5, 'Kurti', 'Soft cotton Fashionable Kurti.', 1299.00, 'images/Kurti.jpg', 60, 2),
  (6, 'Pant', 'Soft cotton Trendy Pant.', 799.00, 'images/pant1.jpg', 80, 2),
  (7, 'Jeans', 'Comfortable Denim Jeans.', 699.00, 'images/pant2.jpg', 70, 2),
  (8, 'Shirt', 'Chequered cotton Collared Shirt.', 1099.00, 'images/shirt1.jpg', 90, 2),
  (9, 'Top', 'Designer new Top.', 999.00, 'images/top1.jpg', 55, 2),
  (10,'Top', 'Designer new Top.', 999.00, 'images/top2.jpg', 45, 2),
  (11,'Smartphone', 'Feature-packed Android phone.', 18000.00, 'images/mobile.png', 50, 1),
  (12,'Sofa', 'Comfy 3-seater.', 12000.00, 'images/furniture.jpg', 10, 3),
  (13,'Snack Box', 'Mixed treats pack.', 299.00, 'images/grocery.jpg', 200, 4)
ON DUPLICATE KEY UPDATE
  name = VALUES(name),
  description = VALUES(description),
  price = VALUES(price),
  image_url = VALUES(image_url),
  stock = VALUES(stock),
  category_id = VALUES(category_id);
