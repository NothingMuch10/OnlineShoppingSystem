package com.buzzbuy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuzzbuyApplication {
  public static void main(String[] args) {
    SpringApplication.run(BuzzbuyApplication.class, args);
  }
  
}
