// src/main/java/com/buzzbuy/controller/OrderController.java
package com.buzzbuy.controller;

import com.buzzbuy.config.JwtUtil;
import com.buzzbuy.dto.OrderDto;
import com.buzzbuy.dto.PlaceOrderRequest;
import com.buzzbuy.entity.*;
import com.buzzbuy.repo.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

  private final OrderRepository orderRepo;
  private final OrderItemRepository orderItemRepo; // may be unused if you set cascade on Order
  private final CartItemRepository cartRepo;
  private final UserRepository userRepo;
  private final JwtUtil jwt;

  public OrderController(OrderRepository orderRepo,
                         OrderItemRepository orderItemRepo,
                         CartItemRepository cartRepo,
                         UserRepository userRepo,
                         JwtUtil jwt) {
    this.orderRepo = orderRepo;
    this.orderItemRepo = orderItemRepo;
    this.cartRepo = cartRepo;
    this.userRepo = userRepo;
    this.jwt = jwt;
  }

  private Long currentUserId(HttpServletRequest request) {
    String authHeader = request.getHeader("Authorization");
    if (authHeader == null || !authHeader.startsWith("Bearer ")) return null;
    String token = authHeader.substring(7);
    String email = jwt.getSubject(token);
    return userRepo.findByEmail(email).map(User::getId).orElse(null);
  }

  @GetMapping
  public ResponseEntity<List<OrderDto>> listOrders(HttpServletRequest req) {
    Long uid = currentUserId(req);
    if (uid == null) return ResponseEntity.status(401).build();
    List<OrderDto> out = orderRepo.findByUser_IdOrderByCreatedAtDesc(uid)
        .stream().map(OrderDto::from).collect(Collectors.toList());
    return ResponseEntity.ok(out);
  }

  // Accept both /api/orders and /api/orders/checkout for compatibility
  @PostMapping
  @Transactional
  public ResponseEntity<OrderDto> placeOrder(HttpServletRequest req,
                                             @Valid @RequestBody PlaceOrderRequest body) {
    return doCheckout(req, body);
  }

  @PostMapping("/checkout")
  @Transactional
  public ResponseEntity<OrderDto> placeOrderAlias(HttpServletRequest req,
                                                  @Valid @RequestBody PlaceOrderRequest body) {
    return doCheckout(req, body);
  }

  private ResponseEntity<OrderDto> doCheckout(HttpServletRequest req, PlaceOrderRequest body) {
    Long uid = currentUserId(req);
    if (uid == null) return ResponseEntity.status(401).build();

    User user = userRepo.findById(uid).orElseThrow();
    List<CartItem> cartItems = cartRepo.findByUser_Id(uid);
    if (cartItems.isEmpty()) {
      // you have a GlobalExceptionHandler; but returning 400 here is fine
      return ResponseEntity.badRequest().build();
    }

    Order order = new Order();
    order.setUser(user);
    order.setPaymentMethod(body.paymentMethod());
    order.setShippingName(body.shippingName());
    order.setShippingEmail(body.shippingEmail());
    order.setShippingAddress(body.shippingAddress());
    order.setStatus("PENDING"); // set PAID if you want to simulate success

    BigDecimal total = BigDecimal.ZERO;

    // Build items
    for (CartItem ci : cartItems) {
      OrderItem oi = new OrderItem();
      oi.setOrder(order);
      oi.setProduct(ci.getProduct());
      oi.setQuantity(ci.getQuantity());
      // Product#getPrice should be BigDecimal in your entity
      oi.setPrice(ci.getProduct().getPrice());

      order.getItems().add(oi);

      total = total.add(oi.getPrice().multiply(BigDecimal.valueOf(oi.getQuantity())));
    }

    order.setTotalAmount(total);

    // Persist order (+ items via cascade if you've added it)
    Order saved = orderRepo.save(order);

    // If you did NOT add cascade on Order.items, uncomment:
    // orderItemRepo.saveAll(saved.getItems());

    // Clear cart
    cartRepo.deleteByUser_Id(uid);

    // Optional: mark as PAID now
    // saved.setStatus("PAID");
    // saved = orderRepo.save(saved);

    return ResponseEntity.ok(OrderDto.from(saved));
  }
}
