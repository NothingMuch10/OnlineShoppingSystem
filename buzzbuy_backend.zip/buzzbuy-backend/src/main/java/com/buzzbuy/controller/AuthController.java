package com.buzzbuy.controller;

import com.buzzbuy.entity.User;
import com.buzzbuy.repo.UserRepository;
import com.buzzbuy.config.JwtUtil;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtUtil jwt;

    public AuthController(UserRepository users, PasswordEncoder encoder, JwtUtil jwt) {
        this.users = users;
        this.encoder = encoder;
        this.jwt = jwt;
    }

    public record LoginRequest(@NotBlank String email, @NotBlank String password) {}
    public record RegisterRequest(@NotBlank String name, @NotBlank String email, String mobile, @NotBlank String password) {}

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        User u = users.findByEmail(req.email()).orElse(null);
        if (u == null) return ResponseEntity.status(401).body(Map.of("message", "Invalid credentials"));

        if (!encoder.matches(req.password(), u.getPasswordHash())) {
            return ResponseEntity.status(401).body(Map.of("message", "Invalid credentials"));
        }

        // ✅ build claims map
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", u.getRole());

        String token = jwt.generateToken(u.getEmail(), claims);

        return ResponseEntity.ok(Map.of(
                "token", token,
                "user", Map.of("id", u.getId(), "name", u.getName(), "email", u.getEmail(), "role", u.getRole())
        ));
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        if (users.findByEmail(req.email()).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Email already used"));
        }

        User u = new User();
        u.setName(req.name());
        u.setEmail(req.email());
        u.setMobile(req.mobile());
        u.setPasswordHash(encoder.encode(req.password()));
        u.setRole("USER");
        users.save(u);

        // ✅ build claims map
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", u.getRole());

        String token = jwt.generateToken(u.getEmail(), claims);

        return ResponseEntity.ok(Map.of(
                "token", token,
                "user", Map.of("id", u.getId(), "name", u.getName(), "email", u.getEmail(), "role", u.getRole())
        ));
    }
}
