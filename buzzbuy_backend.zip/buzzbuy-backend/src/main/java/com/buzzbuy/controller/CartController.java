package com.buzzbuy.controller;

import com.buzzbuy.dto.AddToCartRequest;
import com.buzzbuy.dto.CartItemDto;
import com.buzzbuy.entity.CartItem;
import com.buzzbuy.entity.Product;
import com.buzzbuy.entity.User;
import com.buzzbuy.repo.CartItemRepository;
import com.buzzbuy.repo.ProductRepository;
import com.buzzbuy.repo.UserRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired private CartItemRepository cartRepo;
    @Autowired private ProductRepository productRepo;
    @Autowired private UserRepository userRepo;

    // Extract current user id from authenticated principal
    private Long currentUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || auth.getName() == null) {
            throw new RuntimeException("Unauthorized");
        }
        String email = auth.getName(); // email was set in JwtAuthFilter
        User u = userRepo.findByEmail(email).orElseThrow(
                () -> new RuntimeException("User not found: " + email));
        return u.getId();
    }

    @GetMapping
    public List<CartItemDto> getCart() {
        Long uid = currentUserId();
        return cartRepo.findByUser_Id(uid)
                .stream()
                .map(CartItemDto::from)
                .collect(Collectors.toList());
    }

    @PostMapping
    public ResponseEntity<CartItemDto> add(@Valid @RequestBody AddToCartRequest body) {
        Long uid = currentUserId();
        User user = userRepo.findById(uid).orElseThrow();
        Product prod = productRepo.findById(body.productId()).orElseThrow();

        CartItem item = cartRepo.findByUser_IdAndProduct_Id(user.getId(), prod.getId())
                .orElseGet(() -> {
                    CartItem ci = new CartItem();
                    ci.setUser(user);
                    ci.setProduct(prod);
                    ci.setQuantity(0);
                    return ci;
                });

        int inc = (body.quantity() == null || body.quantity() < 1) ? 1 : body.quantity();
        item.setQuantity(item.getQuantity() + inc);
        cartRepo.save(item);

        return ResponseEntity.ok(CartItemDto.from(item));
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<CartItemDto> update(@PathVariable Long itemId,
                                              @RequestParam int quantity) {
        Long uid = currentUserId();
        CartItem item = cartRepo.findById(itemId).orElseThrow();

        // security: only owner can update
        if (!item.getUser().getId().equals(uid)) {
            return ResponseEntity.status(403).build();
        }

        if (quantity <= 0) {
            cartRepo.delete(item);
            return ResponseEntity.noContent().build();
        }
        item.setQuantity(quantity);
        cartRepo.save(item);
        return ResponseEntity.ok(CartItemDto.from(item));
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> remove(@PathVariable Long itemId) {
        Long uid = currentUserId();
        CartItem item = cartRepo.findById(itemId).orElseThrow();

        if (!item.getUser().getId().equals(uid)) {
            return ResponseEntity.status(403).build();
        }

        cartRepo.delete(item);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping
    public ResponseEntity<Void> clear() {
        Long uid = currentUserId();
        cartRepo.deleteByUser_Id(uid);
        return ResponseEntity.noContent().build();
    }
}
