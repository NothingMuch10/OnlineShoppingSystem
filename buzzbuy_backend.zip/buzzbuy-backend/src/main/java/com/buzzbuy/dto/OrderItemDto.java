package com.buzzbuy.dto;

import com.buzzbuy.entity.OrderItem;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class OrderItemDto {
  private Long id;
  private Long productId;
  private String name;
  private BigDecimal price;
  private Integer quantity;

  public static OrderItemDto from(OrderItem oi) {
    OrderItemDto d = new OrderItemDto();
    d.id = oi.getId();
    d.productId = oi.getProduct().getId();
    d.name = oi.getProduct().getName();
    d.price = oi.getPrice();
    d.quantity = oi.getQuantity();
    return d;
  }
}
