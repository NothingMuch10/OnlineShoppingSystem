package com.buzzbuy.dto;

import com.buzzbuy.entity.Order;
import com.buzzbuy.entity.OrderItem;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Data;


public class OrderDto {
    private Long id;
    private String status;
    private BigDecimal totalAmount;
    private String paymentMethod;
    private String shippingName;
    private String shippingEmail;
    private String shippingAddress;
    private Instant createdAt;
    private List<OrderItemDto> items;

    // Nested DTO for order items
    public static class OrderItemDto {
        public String productName;
        public BigDecimal price;
        public Integer quantity;

        public static OrderItemDto from(OrderItem oi) {
            OrderItemDto dto = new OrderItemDto();
            dto.productName = oi.getProduct().getName();
            dto.price = oi.getPrice();
            dto.quantity = oi.getQuantity();
            return dto;
        }
    }

    public static OrderDto from(Order o) {
        OrderDto dto = new OrderDto();
        dto.id = o.getId();
        dto.status = o.getStatus();
        dto.totalAmount = o.getTotalAmount();
        dto.paymentMethod = o.getPaymentMethod();
        dto.shippingName = o.getShippingName();
        dto.shippingEmail = o.getShippingEmail();
        dto.shippingAddress = o.getShippingAddress();
        dto.createdAt = o.getCreatedAt();
        dto.items = o.getItems().stream().map(OrderItemDto::from).collect(Collectors.toList());
        return dto;
    }

    // getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
    public String getShippingName() { return shippingName; }
    public void setShippingName(String shippingName) { this.shippingName = shippingName; }
    public String getShippingEmail() { return shippingEmail; }
    public void setShippingEmail(String shippingEmail) { this.shippingEmail = shippingEmail; }
    public String getShippingAddress() { return shippingAddress; }
    public void setShippingAddress(String shippingAddress) { this.shippingAddress = shippingAddress; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public List<OrderItemDto> getItems() { return items; }
    public void setItems(List<OrderItemDto> items) { this.items = items; }
    
}
