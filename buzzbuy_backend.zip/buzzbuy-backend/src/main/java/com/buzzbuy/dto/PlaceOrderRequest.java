// src/main/java/com/buzzbuy/dto/PlaceOrderRequest.java
package com.buzzbuy.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record PlaceOrderRequest(
    @NotBlank String shippingName,
    @Email @NotBlank String shippingEmail,
    @NotBlank String shippingAddress,
    @NotBlank String paymentMethod // COD / CARD / UPI
) {}
