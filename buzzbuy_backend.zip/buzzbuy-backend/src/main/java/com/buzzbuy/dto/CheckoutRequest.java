package com.buzzbuy.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CheckoutRequest {
  @NotBlank private String shippingName;
  @Email @NotBlank private String shippingEmail;
  @NotBlank private String shippingAddress;
  @NotBlank private String paymentMethod; // COD / CARD / UPI
}
