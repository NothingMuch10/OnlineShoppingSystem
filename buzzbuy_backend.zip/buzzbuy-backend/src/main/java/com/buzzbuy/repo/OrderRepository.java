// src/main/java/com/buzzbuy/repo/OrderRepository.java
package com.buzzbuy.repo;

import com.buzzbuy.entity.Order;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {
  List<Order> findByUser_IdOrderByCreatedAtDesc(Long userId);
}
