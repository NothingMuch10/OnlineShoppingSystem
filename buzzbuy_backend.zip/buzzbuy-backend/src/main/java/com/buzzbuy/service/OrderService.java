package com.buzzbuy.service;

import com.buzzbuy.dto.CheckoutRequest;
import com.buzzbuy.entity.CartItem;
import com.buzzbuy.entity.Order;
import com.buzzbuy.entity.OrderItem;
import com.buzzbuy.entity.Product;
import com.buzzbuy.entity.User;
import com.buzzbuy.repo.CartItemRepository;
import com.buzzbuy.repo.OrderItemRepository;
import com.buzzbuy.repo.OrderRepository;
import com.buzzbuy.repo.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OrderService {

  private final UserRepository userRepo;
  private final CartItemRepository cartRepo;
  private final OrderRepository orderRepo;
  private final OrderItemRepository orderItemRepo;

  @Transactional
  public Order checkout(Long userId, CheckoutRequest req) {
    User user = userRepo.findById(userId).orElseThrow(() ->
        new EntityNotFoundException("User not found"));

    List<CartItem> cart = cartRepo.findByUser_Id(userId);
    if (cart.isEmpty()) {
      throw new IllegalStateException("Cart is empty");
    }

    // Build order
    Order order = new Order();
    order.setUser(user);
    order.setStatus("PENDING");
    order.setPaymentMethod(req.getPaymentMethod());
    order.setShippingName(req.getShippingName());
    order.setShippingEmail(req.getShippingEmail());
    order.setShippingAddress(req.getShippingAddress());

    BigDecimal total = BigDecimal.ZERO;

    for (CartItem ci : cart) {
      Product p = ci.getProduct();
      BigDecimal price = p.getPrice(); // authoritative price snapshot

      OrderItem oi = new OrderItem();
      oi.setOrder(order);
      oi.setProduct(p);
      oi.setPrice(price);
      oi.setQuantity(ci.getQuantity());

      order.getItems().add(oi);

      total = total.add(price.multiply(BigDecimal.valueOf(ci.getQuantity())));
      // Optional: stock checks / decrement here if you track stock strictly
      // if (p.getStock() < ci.getQuantity()) throw new IllegalStateException("Insufficient stock");
      // p.setStock(p.getStock() - ci.getQuantity());
    }

    order.setTotalAmount(total);

    // Persist
    Order saved = orderRepo.save(order);
    orderItemRepo.saveAll(saved.getItems());

    // Clear cart
    cartRepo.deleteByUser_Id(userId);

    // Optional: set PAID if you simulate payment success here
    saved.setStatus("PAID");
    return orderRepo.save(saved);
  }

  public List<Order> listForUser(Long userId) {
    // You can add a custom repo method findByUser_IdOrderByCreatedAtDesc if needed
    return orderRepo.findAll().stream()
        .filter(o -> o.getUser().getId().equals(userId))
        .sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()))
        .toList();
  }

  public Order getOneForUser(Long userId, Long orderId) {
    Order o = orderRepo.findById(orderId).orElseThrow(() -> new EntityNotFoundException("Order not found"));
    if (!o.getUser().getId().equals(userId)) {
      throw new SecurityException("Forbidden");
    }
    return o;
  }
}
