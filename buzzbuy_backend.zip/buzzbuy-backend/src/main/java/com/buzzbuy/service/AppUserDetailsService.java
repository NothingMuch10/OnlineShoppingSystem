package com.buzzbuy.service;

import com.buzzbuy.entity.User;
import com.buzzbuy.repo.UserRepository;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class AppUserDetailsService implements UserDetailsService {

  private final UserRepository repo;

  public AppUserDetailsService(UserRepository repo) {
    this.repo = repo;
  }

  @Override
  public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
    User u = repo.findByEmail(email)
        .orElseThrow(() -> new UsernameNotFoundException("No user found with email " + email));

    return org.springframework.security.core.userdetails.User
        .withUsername(u.getEmail())
        .password(u.getPasswordHash())  // this must be the BCrypt hash in DB
        .roles(u.getRole())             // "USER" or "ADMIN"
        .build();
  }
}
