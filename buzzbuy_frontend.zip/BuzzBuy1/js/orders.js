// orders.js
const API_BASE = "http://localhost:8080";
const ORDER_API = `${API_BASE}/api/orders`;

function formatINR(n) {
  return new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(Number(n || 0));
}

$(async function () {
  const $list = $("#orders-list");

  try {
    const res = await authFetch(ORDER_API);
    if (!res.ok) throw new Error("Failed to load orders");

    const orders = await res.json();
    if (!orders.length) {
      $list.html(`<div class="text-muted">You have not placed any orders yet.</div>`);
      return;
    }

    $list.empty();
    orders.forEach(order => {
      const itemsHtml = (order.items || [])
        .map(it => `
          <li class="list-group-item d-flex justify-content-between align-items-center">
            ${it.productName} (x${it.quantity})
            <span>₹${formatINR(it.price * it.quantity)}</span>
          </li>
        `).join("");

      $list.append(`
        <div class="card mb-4 shadow-sm">
          <div class="card-header d-flex justify-content-between">
            <span><strong>Order #${order.id}</strong> — ${order.status}</span>
            <small class="text-muted">${new Date(order.createdAt).toLocaleString()}</small>
          </div>
          <ul class="list-group list-group-flush">
            ${itemsHtml}
          </ul>
          <div class="card-footer d-flex justify-content-between">
            <span>Payment: ${order.paymentMethod}</span>
            <span class="fw-bold">Total: ₹${formatINR(order.totalAmount)}</span>
          </div>
          <div class="card-body">
            <p class="mb-0">
              <strong>Ship To:</strong> ${order.shippingName}, ${order.shippingAddress}
              <br>
              <small class="text-muted">${order.shippingEmail}</small>
            </p>
          </div>
        </div>
      `);
    });
  } catch (e) {
    console.error(e);
    $list.html(`<div class="text-danger">❌ Could not load orders.</div>`);
  }
});
