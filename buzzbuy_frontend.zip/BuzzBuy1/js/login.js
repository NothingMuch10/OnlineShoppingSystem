// js/login.js
(() => {
  const API_BASE = window.API_BASE || "http://localhost:8080";
  const byId = id => document.getElementById(id);

  function saveAuth(token, user) {
  try {
    // new keys
    localStorage.setItem("bb_token", token);
    localStorage.setItem("bb_user", JSON.stringify(user));
    // legacy keys for older pages that still read them
    localStorage.setItem("jwt", token);
    localStorage.setItem("user", JSON.stringify(user));
  } catch {}
}


  const setBusy = (busy) => {
    const btn = byId("login-btn");
    const spin = byId("login-spin");
    const text = btn?.querySelector(".btn-text");
    if (btn) btn.disabled = busy;
    if (spin) spin.classList.toggle("d-none", !busy);
    if (text) text.style.opacity = busy ? ".6" : "1";
  };
  const showError = (msg) => {
    const box = byId("login-error");
    if (box) { box.textContent = msg || "Login failed."; box.classList.remove("d-none"); }
  };
  const hideError = () => { byId("login-error")?.classList.add("d-none"); };

  function bindPasswordToggle() {
    const btn = byId("toggle-pass");
    const input = byId("password");
    if (!btn || !input) return;
    btn.addEventListener("click", () => {
      const t = input.type === "password" ? "text" : "password";
      input.type = t;
      btn.innerHTML = t === "password" ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
    });
  }

  async function handleSubmit(e) {
    if (!(e.target && e.target.id === "login-form")) return;
    e.preventDefault();
    hideError();

    const email = byId("email")?.value?.trim();
    const password = byId("password")?.value ?? "";

    if (!email || !password) {
      showError("Please enter email and password.");
      return;
    }

    setBusy(true);
    try {
      const res = await fetch(`${API_BASE}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        showError(data?.details || data?.error || "Invalid credentials.");
        return;
      }
      if (data?.token && data?.user) {
        saveAuth(data.token, data.user);
        location.assign("index.html");
      } else {
        showError("Unexpected response from server.");
      }
    } catch {
      showError("Network error. Is the backend running on 8080?");
    } finally {
      setBusy(false);
    }
  }

  function init() {
    bindPasswordToggle();
    document.addEventListener("submit", handleSubmit, true);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
