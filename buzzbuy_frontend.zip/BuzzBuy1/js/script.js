// js/script.js
// =================== CONFIG ===================
const API_BASE = "http://localhost:8080";
const CART_API = `${API_BASE}/api/cart`;
const PRODUCTS_API = `${API_BASE}/api/products`;

// =================== AUTH HELPERS ===================
function getUser() {
  try { return JSON.parse(localStorage.getItem("bb_user") || "null"); } catch { return null; }
}
window.getToken = () => localStorage.getItem("bb_token") || null;

window.authFetch = (url, options = {}) => {
  const token = window.getToken();
  const headers = new Headers(options.headers || {});
  if (token) headers.set("Authorization", "Bearer " + token);
  if (!headers.has("Content-Type") && options.body && typeof options.body === "object") {
    headers.set("Content-Type", "application/json");
    options.body = JSON.stringify(options.body);
  }
  return fetch(url, { ...options, headers });
};

// Toggle header auth state
function updateAuthUI() {
  const user = getUser();
  const isLoggedIn = !!getToken() && !!user;

  const $login = $("#nav-login");
  const $register = $("#nav-register");
  const $user = $("#nav-user");
  const $name = $("#nav-username");

  if (isLoggedIn) {
    $login.addClass("d-none");
    $register.addClass("d-none");
    $user.removeClass("d-none");
    if ($name.length) $name.text(user?.name || "Account");
  } else {
    $login.removeClass("d-none");
    $register.removeClass("d-none");
    $user.addClass("d-none");
    setCartBadge(0);
  }
  refreshCartCountBadge();
}

// Delegated logout (works on every page, header is injected)
$(document).on("click", "#nav-logout", function (e) {
  e.preventDefault();
  ["bb_token", "bb_user", "jwt", "user"].forEach(k => localStorage.removeItem(k));
  localStorage.removeItem("cartCount");
  updateAuthUI();
  location.assign("index.html");
});

// =================== THEME ===================
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem("theme", theme);
  const icon = document.getElementById("theme-icon");
  if (icon) {
    icon.classList.toggle("fa-sun", theme === "dark");
    icon.classList.toggle("fa-moon", theme !== "dark");
  }
}
function initTheme() {
  const saved = localStorage.getItem("theme");
  if (saved === "light" || saved === "dark") {
    applyTheme(saved);
  } else {
    const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    applyTheme(prefersDark ? "dark" : "light");
  }
}

// =================== HEADER/FOOTER INJECTION ===================
function loadHeaderFooter() {
  $("#header").load("header.html", function () {
    // Make sure dropdown works on injected header
    if (window.bootstrap && bootstrap.Dropdown) {
      document.querySelectorAll('[data-bs-toggle="dropdown"]').forEach(el => {
        if (!el._bbInit) { new bootstrap.Dropdown(el); el._bbInit = true; }
      });
    }

    initTheme();
    // Theme button uses delegation so it survives header reloads
    $(document).off("click.bbTheme").on("click.bbTheme", "#theme-toggle", function () {
      const current = document.documentElement.getAttribute("data-theme") || "light";
      applyTheme(current === "light" ? "dark" : "light");
    });

    updateAuthUI();
  });

  $("#footer").load("footer.html");
}

// =================== CART HELPERS ===================
function setCartBadge(n) {
  const el = document.getElementById("cart-count");
  if (el) el.textContent = String(n ?? 0);
}
function getCartLS() {
  return JSON.parse(localStorage.getItem("cart") || "[]");
}
function saveCartLS(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
}
function cartCountFromLS() {
  return getCartLS().reduce((n, it) => n + (it.quantity || 0), 0);
}

async function apiGetCart() {
  const res = await authFetch(CART_API, { method: "GET" });
  if (!res.ok) throw new Error("cart list failed");
  return res.json();
}
async function apiAddToCart(productId, qty = 1) {
  const res = await authFetch(CART_API, { method: "POST", body: { productId, quantity: qty } });
  if (!res.ok) throw new Error("cart add failed");
  return res.json();
}
async function apiUpdateItem(itemId, quantity) {
  const res = await authFetch(`${CART_API}/${itemId}?quantity=${quantity}`, { method: "PUT" });
  if (res.status === 204) return null;
  if (!res.ok) throw new Error("cart update failed");
  return res.json();
}
async function apiDeleteItem(itemId) {
  const res = await authFetch(`${CART_API}/${itemId}`, { method: "DELETE" });
  if (!(res.ok || res.status === 204)) throw new Error("cart delete failed");
}
async function apiClearCart() {
  const res = await authFetch(CART_API, { method: "DELETE" });
  if (!(res.ok || res.status === 204)) throw new Error("cart clear failed");
}

// Exposed globally (checkout.js calls this)
async function refreshCartCountBadge() {
  const badge = document.getElementById("cart-count");
  if (!badge) return;
  try {
    const items = await apiGetCart();
    const count = items.reduce((n, it) => n + (it.quantity || 0), 0);
    setCartBadge(count);
  } catch {
    setCartBadge(cartCountFromLS());
  }
}
window.refreshCartCountBadge = refreshCartCountBadge;

// =================== UI HELPERS ===================
function formatINR(n) {
  return new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(Number(n || 0));
}
function imageForProduct(p) {
  if (p.imageUrl && String(p.imageUrl).trim() !== "") return p.imageUrl;
  const name = (p.name || "").toLowerCase();
  const cat = (p.category?.name || "").toLowerCase();
  if (cat.includes("electronics")) return name.includes("phone") ? "images/mobile.png" : "images/laptop.jpg";
  if (cat.includes("clothing")) return "images/pant.png";
  if (cat.includes("furniture")) return "images/furniture.jpg";
  if (cat.includes("food")) return "images/grocery.jpg";
  return "images/laptop.jpg";
}
function productCard(p) {
  const category = p.category?.name || "";
  const img = imageForProduct(p);
  const price = Number(p.price || 0);
  return `
    <div class="col-md-4 mb-4 product-card" data-category="${category}">
      <div class="card card-sh h-100">
        <img src="${img}" class="card-img-top" alt="${p.name}">
        <div class="card-body">
          <h5 class="card-title">${p.name}</h5>
          <p class="card-text">${p.description || ""}</p>
          <p><strong>₹${formatINR(price)}</strong></p>
          <a href="view_product.html?id=${p.id}" class="btn btn-outline-primary btn-sm">View Details</a>
          <button class="btn btn-success btn-sm add-to-cart"
            data-product-id="${p.id}"
            data-product='${JSON.stringify({ id: p.id, name: p.name, category, price })}'>
            Add to Cart
          </button>
        </div>
      </div>
    </div>`;
}

// =================== PAGE BOOT ===================
$(function () {
  // Always load header/footer
  loadHeaderFooter();

  const params = new URLSearchParams(window.location.search);
  const categoryFilter = params.get("category");

  // ---------- Products page ----------
  (async function loadProducts() {
    const $grid = $("#product-grid");
    if (!$grid.length) return;
    try {
      const res = await fetch(PRODUCTS_API);
      if (!res.ok) throw new Error("Failed to load products");
      let products = await res.json();
      if (categoryFilter) {
        products = products.filter(
          p => (p.category?.name || "").toLowerCase() === categoryFilter.toLowerCase()
        );
        const h2 = $("h2:first");
        if (h2.length) h2.text(`Products — ${categoryFilter}`);
      }
      if (!products.length) {
        $grid.html(`<div class="col-12 text-muted">No products found.</div>`);
        return;
      }
      $grid.html(products.map(productCard).join(""));
    } catch (e) {
      console.error(e);
      $("#product-loading").remove();
      $grid.html(`<div class="col-12 text-danger">Could not load products.</div>`);
    }
  })();

  // ---------- Product details page ----------
  (async function loadProductDetails() {
    const $wrap = $("#product-details");
    if (!$wrap.length) return;
    const id = new URLSearchParams(window.location.search).get("id");
    if (!id) {
      $wrap.html(`<div class="col-12 text-danger">Missing product ID.</div>`);
      return;
    }
    try {
      const res = await fetch(`${PRODUCTS_API}/${id}`);
      if (!res.ok) throw new Error("Failed to load product");
      const p = await res.json();
      const img = imageForProduct(p);
      const price = Number(p.price || 0);
      $wrap.html(`
        <div class="col-md-6">
          <div class="card border-0 shadow-sm">
            <img src="${img}" class="img-fluid rounded-top" alt="${p.name}">
          </div>
        </div>
        <div class="col-md-6">
          <h2 class="mb-2">${p.name}</h2>
          <div class="mb-2"><span class="badge category">${p.category?.name || "General"}</span></div>
          <p class="text-muted">${p.description || ""}</p>
          <h4 class="text-success mb-3">₹${formatINR(price)}</h4>
          <button class="btn btn-success add-to-cart"
            data-product-id="${p.id}"
            data-product='${JSON.stringify({ id: p.id, name: p.name, category: p.category?.name || "", price })}'>
            <i class="fas fa-cart-plus"></i> Add to Cart
          </button>
        </div>`);
    } catch (e) {
      console.error(e);
      $wrap.html(`<div class="col-12 text-danger">Could not load product.</div>`);
    } finally {
      $("#product-details-loading").remove();
    }
  })();

  // ---------- CART (backend first, fallback LS) ----------
  async function renderCartBackend() {
    const $tbody = $("#cart-body");
    const $summary = $("#cart-summary");
    if (!$tbody.length) return false;

    try {
      const items = await apiGetCart();
      $tbody.empty();
      if (!items.length) {
        $tbody.append(`<tr><td colspan="5" class="text-center py-4">🛒 Your cart is empty.</td></tr>`);
        $("#totalAmount").text("0");
        $summary.show();
        return true;
      }
      let total = 0;
      items.forEach((item) => {
        const line = (Number(item.price) || 0) * (item.quantity || 1);
        total += line;
        $tbody.append(`
          <tr data-item-id="${item.id}">
            <td>${item.name}</td>
            <td><span class="badge bg-light text-dark">${item.category || ""}</span></td>
            <td>
              <div class="d-inline-flex align-items-center gap-2">
                <button class="btn btn-sm btn-outline-secondary decrease">−</button>
                <span class="fw-semibold qty">${item.quantity}</span>
                <button class="btn btn-sm btn-outline-secondary increase">+</button>
              </div>
            </td>
            <td>₹${formatINR(line)}</td>
            <td><button class="btn btn-sm btn-outline-danger remove"><i class="fa fa-trash"></i></button></td>
          </tr>`);
      });
      $("#totalAmount").text(formatINR(total));
      $summary.show();
      return true;
    } catch {
      return false;
    }
  }

  function renderCartLocal() {
    const $tbody = $("#cart-body");
    const $summary = $("#cart-summary");
    if (!$tbody.length) return;

    const cart = getCartLS();
    $tbody.empty();
    if (cart.length === 0) {
      $tbody.append(`<tr><td colspan="5" class="text-center py-4">🛒 Your cart is empty.</td></tr>`);
      $("#totalAmount").text("0");
      $summary.show();
      return;
    }
    let total = 0;
    cart.forEach((item, idx) => {
      const line = (Number(item.price) || 0) * (item.quantity || 1);
      total += line;
      $tbody.append(`
        <tr data-ls-index="${idx}">
          <td>${item.name}</td>
          <td><span class="badge bg-light text-dark">${item.category}</span></td>
          <td>
            <div class="d-inline-flex align-items-center gap-2">
              <button class="btn btn-sm btn-outline-secondary decrease">−</button>
              <span class="fw-semibold qty">${item.quantity}</span>
              <button class="btn btn-sm btn-outline-secondary increase">+</button>
            </div>
          </td>
          <td>₹${formatINR(line)}</td>
          <td><button class="btn btn-sm btn-outline-danger remove"><i class="fa fa-trash"></i></button></td>
        </tr>`);
    });
    $("#totalAmount").text(formatINR(total));
    $summary.show();
  }

  async function renderCart() {
    const usedBackend = await renderCartBackend();
    if (!usedBackend) renderCartLocal();
    refreshCartCountBadge();
  }
  window.renderCart = renderCart; // helpful if others want to trigger it

  // Add to cart (backend when logged in, else LS)
  $(document).on("click", ".add-to-cart", async function () {
    const meta = $(this).data("product") || {};
    const productId = Number($(this).data("product-id")) || meta.id || null;

    try {
      if (productId && getToken()) {
        await apiAddToCart(productId, 1);
      } else {
        // local fallback
        const cart = getCartLS();
        const ex = productId != null ? cart.find(p => p.id === productId) : cart.find(p => p.name === meta.name);
        if (ex) ex.quantity += 1;
        else cart.push({ id: productId, name: meta.name, category: meta.category, price: meta.price, quantity: 1 });
        saveCartLS(cart);
      }
      await (typeof renderCart === "function" ? renderCart() : refreshCartCountBadge());
    } catch (err) {
      // fallback to local on any error
      const cart = getCartLS();
      const ex = productId != null ? cart.find(p => p.id === productId) : cart.find(p => p.name === meta.name);
      if (ex) ex.quantity += 1;
      else cart.push({ id: productId, name: meta.name, category: meta.category, price: meta.price, quantity: 1 });
      saveCartLS(cart);
      if (typeof renderCart === "function") renderCart(); else refreshCartCountBadge();
    }
  });

  // qty +/- / remove
  $(document).on("click", ".increase, .decrease, .remove", async function () {
    const $tr = $(this).closest("tr");
    const itemId = $tr.data("item-id");   // backend id
    const lsIndex = $tr.data("ls-index"); // local index
    const isInc = $(this).hasClass("increase");
    const isDec = $(this).hasClass("decrease");
    const isRem = $(this).hasClass("remove");

    try {
      if (itemId != null) {
        const qtyEl = $tr.find(".qty");
        let qty = parseInt(qtyEl.text(), 10) || 1;
        if (isInc) qty += 1;
        if (isDec) qty -= 1;
        if (isRem || qty <= 0) await apiDeleteItem(itemId);
        else await apiUpdateItem(itemId, qty);
        await renderCart();
        return;
      }
      throw 0;
    } catch {
      const cart = getCartLS();
      if (lsIndex != null && cart[lsIndex]) {
        if (isInc) cart[lsIndex].quantity += 1;
        if (isDec) cart[lsIndex].quantity -= 1;
        if (isRem || cart[lsIndex].quantity <= 0) cart.splice(lsIndex, 1);
        saveCartLS(cart);
        renderCart();
      }
    }
  });

  // Clear cart
  $(document).on("click", "#clear-cart", async function () {
    try { if (getToken()) await apiClearCart(); else saveCartLS([]); }
    catch { saveCartLS([]); }
    renderCart();
  });

  // Initial render on cart pages (no harm on others)
  renderCart();

  // ---------- Home: New this week ----------
  (async function loadNewThisWeek() {
    const wrap = document.getElementById("new-this-week");
    if (!wrap) return;
    try {
      const res = await fetch(PRODUCTS_API);
      const all = await res.json();
      const pick = all.slice(0, 4);
      wrap.innerHTML = pick.map(p => `
        <div class="col-6 col-md-3">
          <div class="card card-sh h-100">
            <div class="product-zoom">
              <img class="card-img-top" src="${imageForProduct(p)}" alt="${p.name}">
            </div>
            <div class="card-body">
              <div class="fw-semibold">${p.name}</div>
              <div class="text-muted small mb-2">${p.category?.name ?? ""}</div>
              <div class="d-flex justify-content-between align-items-center">
                <span class="fw-semibold">₹${formatINR(p.price || 0)}</span>
                <a href="view_product.html?id=${p.id}" class="btn btn-sm btn-outline-primary">View</a>
              </div>
            </div>
          </div>
        </div>`).join("");
    } catch { /* silent */ }
  })();
});
