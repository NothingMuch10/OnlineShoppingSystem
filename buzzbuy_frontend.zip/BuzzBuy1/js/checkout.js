// js/checkout.js
const API_BASE = "http://localhost:8080";
const CART_API = `${API_BASE}/api/cart`;
const ORDER_API = `${API_BASE}/api/orders`; // your controller is POST /api/orders

function formatINR(n){ return new Intl.NumberFormat("en-IN",{maximumFractionDigits:2}).format(Number(n||0)); }
const getToken = () => localStorage.getItem("bb_token");
const getLocalCart = () => JSON.parse(localStorage.getItem("cart") || "[]");

async function migrateLocalCartIfNeeded() {
  // Only migrate if logged in and server cart is empty but LS has items
  if (!getToken()) return [];
  try {
    let serverItems = await authFetch(CART_API).then(r => r.ok ? r.json() : []);
    if (serverItems.length) return serverItems;

    const ls = getLocalCart();
    if (!ls.length) return [];

    // map names -> product ids when LS items don't carry id
    const prods = await fetch(`${API_BASE}/api/products`).then(r => r.json());
    const findId = (name) => (prods.find(p => (p.name||'').toLowerCase() === (name||'').toLowerCase())||{}).id;

    for (const it of ls) {
      const pid = it.id || findId(it.name);
      if (!pid) { console.warn("No product id for", it); continue; }
      await authFetch(CART_API, {
        method: "POST",
        body: JSON.stringify({ productId: pid, quantity: it.quantity || 1 })
      });
    }
    localStorage.removeItem("cart"); // keep UI in sync
    serverItems = await authFetch(CART_API).then(r => r.json());
    return serverItems;
  } catch (e) {
    console.warn("Migration failed (likely CORS/back-end down):", e);
    return [];
  }
}

// tiny helper that adds Authorization + json Content-Type
function authFetch(url, options = {}) {
  const headers = new Headers(options.headers || {});
  if (options.body && typeof options.body === "string") headers.set("Content-Type","application/json");
  if (!headers.has("Content-Type") && options.body && typeof options.body === "object") {
    headers.set("Content-Type", "application/json");
  }
  const t = getToken();
  if (t) headers.set("Authorization", "Bearer " + t);
  return fetch(url, { ...options, headers });
}

$(async function () {
  // must be logged in to checkout
  if (!getToken()) { alert("Please log in to checkout."); location.assign("login.html"); return; }

  const $orderItems = $("#order-items");
  const $total = $("#checkout-total");
  const $err = $("#checkout-error");
  let total = 0;

  async function loadSummary() {
    $orderItems.empty();
    total = 0;

    // Try server cart first
    try {
      let items = await authFetch(CART_API).then(r => {
        if (r.status === 401) throw new Error("unauthorized");
        if (!r.ok) throw new Error("cart list failed");
        return r.json();
      });

      // If empty, try migrating any local items to server automatically
      if (!items.length) {
        const migrated = await migrateLocalCartIfNeeded();
        if (migrated.length) items = migrated;
      }

      if (!items.length) {
        $orderItems.append(`<li class="list-group-item text-center">Your cart is empty.</li>`);
      } else {
        items.forEach(it => {
          const line = (Number(it.price) || 0) * (it.quantity || 1);
          total += line;
          $orderItems.append(`
            <li class="list-group-item d-flex justify-content-between align-items-center">
              ${it.name} (x${it.quantity})
              <span>₹${formatINR(line)}</span>
            </li>
          `);
        });
      }
      $total.text(formatINR(total));
    } catch (e) {
      // Backend unreachable: show LS cart so the user sees something
      const ls = getLocalCart();
      if (!ls.length) {
        $orderItems.append(`<li class="list-group-item text-center">Your cart is empty.</li>`);
      } else {
        ls.forEach(it => {
          const line = (Number(it.price) || 0) * (it.quantity || 1);
          total += line;
          $orderItems.append(`
            <li class="list-group-item d-flex justify-content-between align-items-center">
              ${it.name} (x${it.quantity})
              <span>₹${formatINR(line)}</span>
            </li>
          `);
        });
        $total.text(formatINR(total));
      }
    }
  }

  await loadSummary();

  $("#checkout-form").on("submit", async function (e) {
    e.preventDefault();
    $err.addClass("d-none").text("");

    const payload = {
      shippingName:  $("#fullName").val()?.trim(),
      shippingEmail: $("#email").val()?.trim(),
      shippingAddress: $("#address").val()?.trim(),
      paymentMethod: $("#paymentMethod").val() || "COD"
    };

    if (!payload.shippingName || !payload.shippingEmail || !payload.shippingAddress) {
      $err.removeClass("d-none").text("Please fill name, email and address.");
      return;
    }

    try {
      $("#checkout-btn").prop("disabled", true);
      $("#checkout-spin").removeClass("d-none");

      const res = await authFetch(ORDER_API, {
        method: "POST",
        body: JSON.stringify(payload)
      });
      const data = await res.json().catch(()=> ({}));
      if (!res.ok) {
        const msg = data?.error || data?.details || "Checkout failed";
        throw new Error(msg);
      }

      // Success: clear LS cart (server cart is cleared by backend)
      localStorage.removeItem("cart");
      if (typeof refreshCartCountBadge === "function") await refreshCartCountBadge();

      alert(`✅ Order placed! Order #${data.id} — Total ₹${formatINR(data.totalAmount)}.`);
      location.assign("index.html");
    } catch (err) {
      console.error(err);
      $err.removeClass("d-none").text(err.message || "Checkout failed");
    } finally {
      $("#checkout-btn").prop("disabled", false);
      $("#checkout-spin").addClass("d-none");
    }
  });
});
