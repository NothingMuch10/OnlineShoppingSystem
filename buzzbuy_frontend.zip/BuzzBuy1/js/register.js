// register.js (hardened)
(() => {
  const API_BASE = window.API_BASE || "http://localhost:8080";

  const $ = sel => document.querySelector(sel);
  const byId = id => document.getElementById(id);

  // UI helpers
  const setBusy = (busy) => {
    const btn = byId("register-btn");
    const spin = byId("register-spin");
    const text = btn?.querySelector(".btn-text");
    if (btn) btn.disabled = busy;
    if (spin) spin.classList.toggle("d-none", !busy);
    if (text) text.style.opacity = busy ? ".6" : "1";
  };
  const showError = (msg) => {
    const box = byId("register-error");
    if (box) { box.textContent = msg || "Registration failed."; box.classList.remove("d-none"); }
    const ok = byId("register-success"); if (ok) ok.classList.add("d-none");
  };
  const showSuccess = (msg) => {
    const ok = byId("register-success");
    if (ok) { ok.textContent = msg || "Account created! Redirecting…"; ok.classList.remove("d-none"); }
    const err = byId("register-error"); if (err) err.classList.add("d-none");
  };
  const hideAlerts = () => { byId("register-error")?.classList.add("d-none"); byId("register-success")?.classList.add("d-none"); };

  // password toggle (optional)
  function bindPasswordToggle() {
    const btn = byId("toggle-pass");
    const input = byId("password");
    if (!btn || !input) return;
    btn.addEventListener("click", () => {
      const t = input.type === "password" ? "text" : "password";
      input.type = t;
      btn.innerHTML = t === "password" ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
    });
  }

  async function handleSubmit(e) {
    if (!(e.target && e.target.id === "register-form")) return;
    console.log("[register] submit intercepted");
    e.preventDefault();
    hideAlerts();

    const name = byId("name")?.value?.trim();
    const email = byId("email")?.value?.trim();
    const mobile = byId("mobile")?.value?.trim();
    const password = byId("password")?.value ?? "";

    if (!name || !email || !password) {
      showError("Name, email and password are required.");
      return;
    }

    setBusy(true);
    try {
      const res = await fetch(`${API_BASE}/api/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password, mobile: mobile || null }),
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        // backend may send { details: "..."} or { details: { field: "..." } }
        const msg = typeof data?.details === "string"
          ? data.details
          : (data?.error || "Registration failed.");
        showError(msg);
        return;
      }

      showSuccess("Account created! Redirecting to login…");
      setTimeout(() => location.assign("login.html?registered=1"), 900);
    } catch {
      showError("Network error. Is the backend running on 8080?");
    } finally {
      setBusy(false);
    }
  }

  function init() {
    bindPasswordToggle();
    // capture-phase submit handler: catches even if other code stops bubbling
    document.addEventListener("submit", handleSubmit, true);

    // quick visibility check
    if (!byId("register-form")) {
      console.warn("[register] #register-form not found in DOM");
    } else {
      console.log("[register] handler armed");
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
